# Meet the users of Hello Friend theme!

<!--
TEMPLATE:

- https://radoslawkoziel.pl — **Radek Kozieł** (Software designer and developer)

-->

- https://0x44.pw — **Ian Pringle** (System Admin and developer)
- https://adamormsby.com - **Adam Ormsby** (Generalist Programmer - Web, Mobile, Games)
- https://arubacao.com **Christopher Lass** (Software Engineer and DevOps)
- https://blog.agate.pw/ - **Marco Agate** (System Engineer, DevOps)
- https://blog.agung.io - **Agung Pratama** (Software Engineer and DevOps)
- https://blog.jyny.dev/ - **Jyny Chen** (Software Engineer)
- https://blog.lepape.me/ - **François Le Pape** (Student & developer freelance)
- https://blog.toluwalemi.com/ - **Toluwalemi Oluwadare** (Software Engineer and Content Writer)
- https://cobalto.net/ - **Daniel Pessoa** (Sofware Developer and BI Analyst)
- https://eallion.com/ - **大大的小蜗牛** (E-commerce operator)
- https://etra0.github.io/ - **Sebastián Aedo** (Computer Science student, interested in Game Hacking)
- https://fazi1058.github.io **Faezeh Roeinfard** (Student)
- https://felixleger.com/ - **Félix Léger** (Sofware Developer and DevOps)
- https://gabrielacaesar.com/ - **Gabriela Caesar** (Data journalist)
- https://guilhermesteves.dev/ - **Guilherme Esteves** (Software Engineer, Writer, Speaker)
- https://hesec.de - **Patrick Hener** (Security Researcher, Pentester and Coder)
- https://ilya-lesikov.com - **Ilya Lesikov** (DevOps, SRE)
- https://imgalone.com/ - **Iancu makes games alone** (Indie Game Dev)
- https://jonathan.rico.live/ - **Jonathan Rico** (Electronics Engineer)
- https://kartiniteknologi.id/ - **Kartini Teknologi team** (Tech podcast)
- https://mfaishal.com **Faishal Irawan** (Student)
- https://mritd.com/ - **漠然** (Software Engineer and DevOps)
- https://musq.github.io — **Ashish Ranjan** (Software Engineer)
- https://protocod.gitlab.io/blog/ **protocod** (Web Developer)
- https://shinytoyrobots.com - **shinytoyrobots** (Eclectic journaling and essays)
- https://simeononsecurity.ch/ - **SimeonOnSecurity** (Security and Automation Blog)
- https://verso.re/ - **Joan Calabrés** (Security Engineer)
- https://atticuslab.com/ - **Atticus** (Game Server Engineer)
- https://gregbair.dev/ - **Greg Bair** (Developer and App Architect)
- https://www.miroslavbucek.cz - **Miroslav Buček** (Product Manager, Smart Home company owner)
- https://farhamdani.com/ - **Farhamdani** (Freelancer & Nganggur Productive)
- https://fmg3d.com/ - **Finn M Glas** (Aspiring Physicist, Software Developer)
