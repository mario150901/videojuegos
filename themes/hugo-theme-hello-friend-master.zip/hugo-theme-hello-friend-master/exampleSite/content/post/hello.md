+++
title = "Hello Friend"
date = "1986-09-17"
author = "Elliot"
cover = "img/hello.jpg"
description = "\"Hello, friend?\" That's lame. Maybe I should give you a name?"
+++

> "Hello, friend?" That's lame.
> Maybe I should give you a name...
> But that's a slippery slope.
> You're only in my head.
> We have to remember that...
> Shit.
> It's actually happened.
> I'm talking to an imaginary person.
>
> **— Mr. Robot S01E01**



